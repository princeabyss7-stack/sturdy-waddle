# Ton site NextIdea — guide pas à pas (sans coder)

Le site contient : la page d'accueil, les idées, les votes, la connexion par numéro WhatsApp (code à 6 chiffres), et toutes les protections anti-spam.

## Étape 1 — Mettre le site sur Internet (gratuit)
Fais-le sur un ordinateur si possible (sur téléphone, active « Version pour ordinateur » dans ton navigateur).

1. Décompresse le fichier `site-idees.zip`.
2. Crée un compte gratuit sur **github.com**.
3. Clique sur **New repository**, donne un nom (ex : `mon-site`), puis **Create repository**.
4. Clique sur **uploading an existing file**, glisse TOUT le contenu du dossier `site-idees` (dossiers `app`, `components`, `lib` + les fichiers), puis **Commit changes**.
5. Crée un compte gratuit sur **vercel.com** (choisis « Continue with GitHub »).
6. Clique sur **Add New → Project**, choisis ton dépôt `mon-site`, puis **Deploy**.
7. Au bout de 1-2 minutes, Vercel te donne l'adresse de ton site.

## Étape 2 — Tester tout de suite
Ouvre ton site, clique sur **Se connecter**, entre ton numéro : le code s'affiche à l'écran (« Mode test »). Tu peux déjà proposer des idées et voter.
⚠️ Dans ce mode, les données ne sont pas gardées durablement. Fais l'étape 3 pour les conserver.

## Étape 3 — Garder les idées et les votes (gratuit)
1. Crée un compte sur **upstash.com** → **Create Database** (Redis) → choisis la région la plus proche.
2. Dans la page de la base, copie **REST URL** et **REST TOKEN**.
3. Sur Vercel : ton projet → **Settings → Environment Variables**, ajoute :
   - `UPSTASH_REDIS_REST_URL` = l'URL copiée
   - `UPSTASH_REDIS_REST_TOKEN` = le token copié
   - `AUTH_SECRET` = une longue suite de lettres et chiffres au hasard (30 caractères ou plus)
4. Sur Vercel : **Deployments → … → Redeploy**.

## Étape 4 — Vrais codes WhatsApp
1. Va sur **developers.facebook.com**, crée une application « Business », ajoute le produit **WhatsApp**.
2. Dans **WhatsApp → API Setup** : copie le **Phone number ID** et le **token** (pour un token permanent : crée un « utilisateur système » dans Meta Business).
3. Dans **Message Templates**, crée un modèle de catégorie **Authentication**, nommé `otp_code`, langue **Français**, et attends l'approbation de Meta.
4. Sur Vercel, ajoute :
   - `WHATSAPP_TOKEN`
   - `WHATSAPP_PHONE_NUMBER_ID`
   - `WHATSAPP_TEMPLATE_NAME` = `otp_code`
   - `WHATSAPP_TEMPLATE_LANG` = `fr`
5. **Redeploy**. Le mode test disparaît automatiquement : les codes partent sur WhatsApp.

Facultatif : `NEXT_PUBLIC_WHATSAPP_LINK` (lien de ton groupe WhatsApp, affiche un bandeau) et `BLOCKED_PHONES` (numéros à bloquer, séparés par des virgules).

## Bon à savoir
- WhatsApp ne permet pas de savoir à l'avance si un numéro est banni ou spamé. Le site le détecte à l'envoi (pas de WhatsApp, limité anti-spam) et affiche un message clair.
- Un numéro = un compte = un vote par idée.
- Si le déploiement affiche une erreur, copie-la moi ici et je corrige.

'use client';
import { useEffect, useState } from 'react';

type Step = 'phone' | 'code';

export default function PhoneLogin({ onLoggedIn }: { onLoggedIn: (phone: string) => void }) {
  const [step, setStep] = useState<Step>('phone');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [devCode, setDevCode] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ type: 'error' | 'ok'; text: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown(cooldown - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  async function post(url: string, body: object) {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    return r.json();
  }

  async function sendCode() {
    setLoading(true);
    setMsg(null);
    const d = await post('/api/auth/send-otp', { phone });
    setLoading(false);
    if (!d.ok) {
      if (d.retryAfter) setCooldown(d.retryAfter);
      return setMsg({ type: 'error', text: d.message });
    }
    setPhone(d.phone);
    setDevCode(d.devCode || null);
    setStep('code');
    setCooldown(60);
    setMsg({ type: 'ok', text: d.devCode ? d.message : 'Code envoyé sur WhatsApp ✅' });
  }

  async function verify() {
    setLoading(true);
    setMsg(null);
    const d = await post('/api/auth/verify-otp', { phone, code });
    setLoading(false);
    if (!d.ok) return setMsg({ type: 'error', text: d.message });
    onLoggedIn(d.phone);
  }

  return (
    <div className="login">
      <h2>Connexion par WhatsApp</h2>
      {step === 'phone' ? (
        <>
          <p className="muted">Entre ton numéro avec l'indicatif du pays. Tu recevras un code sur WhatsApp.</p>
          <input type="tel" inputMode="tel" placeholder="+241 07 12 34 56" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <button className="btn" disabled={loading || phone.length < 6} onClick={sendCode}>
            {loading ? 'Envoi…' : 'Recevoir le code'}
          </button>
        </>
      ) : (
        <>
          <p className="muted">Code envoyé au {phone}</p>
          {devCode && (
            <p className="devcode">
              🧪 Mode test — ton code est <strong>{devCode}</strong>
            </p>
          )}
          <input inputMode="numeric" maxLength={6} placeholder="123456" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} />
          <button className="btn" disabled={loading || code.length !== 6} onClick={verify}>
            {loading ? 'Vérification…' : 'Valider'}
          </button>
          <button className="btn ghost" disabled={cooldown > 0 || loading} onClick={sendCode}>
            {cooldown > 0 ? `Renvoyer le code (${cooldown}s)` : 'Renvoyer le code'}
          </button>
          <button
            className="btn ghost"
            onClick={() => {
              setStep('phone');
              setCode('');
              setDevCode(null);
              setMsg(null);
            }}
          >
            Changer de numéro
          </button>
        </>
      )}
      {msg && <p className={msg.type === 'error' ? 'error' : 'okmsg'}>{msg.text}</p>}
    </div>
  );
}

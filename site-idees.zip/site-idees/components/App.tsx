'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import PhoneLogin from './PhoneLogin';

type Idea = { id: string; title: string; description: string; author: string; votes: number; voted: boolean; createdAt: number };

const WA_LINK = process.env.NEXT_PUBLIC_WHATSAPP_LINK;

export default function App() {
  const [user, setUser] = useState<{ phone: string } | null>(null);
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [loading, setLoading] = useState(true);
  const [showLogin, setShowLogin] = useState(false);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [m, i] = await Promise.all([fetch('/api/auth/me').then((r) => r.json()), fetch('/api/ideas').then((r) => r.json())]);
      setUser(m.user);
      setIdeas(i.ideas || []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function vote(id: string) {
    if (!user) return setShowLogin(true);
    const r = await fetch('/api/vote', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    if (r.status === 401) return setShowLogin(true);
    load();
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!user) return setShowLogin(true);
    setBusy(true);
    setErr('');
    const r = await fetch('/api/ideas', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title, description: desc }) });
    const d = await r.json();
    setBusy(false);
    if (!d.ok) return setErr(d.message);
    setTitle('');
    setDesc('');
    load();
  }

  async function logout() {
    await fetch('/api/auth/me', { method: 'DELETE' });
    setUser(null);
    load();
  }

  const totalVotes = ideas.reduce((s, i) => s + i.votes, 0);

  return (
    <>
      <header className="top">
        <div className="logo">
          next<span>idea</span> ✦
        </div>
        {user ? (
          <div className="who">
            <span className="muted">{user.phone}</span>
            <button className="btn small ghost" onClick={logout}>
              Déconnexion
            </button>
          </div>
        ) : (
          <button className="btn small" onClick={() => setShowLogin(true)}>
            Se connecter
          </button>
        )}
      </header>

      <main className="wrap">
        <section className="hero">
          <h1>
            Propose. Vote.
            <br />
            <span>Construisons ensemble ✦</span>
          </h1>
          <p className="muted">Les meilleures idées de la communauté deviennent de vrais projets.</p>
          <div className="stats">
            <div>
              <strong>{ideas.length}</strong>
              <span>idées</span>
            </div>
            <div>
              <strong>{totalVotes}</strong>
              <span>votes</span>
            </div>
          </div>
        </section>

        {WA_LINK && (
          <a className="banner" href={WA_LINK} target="_blank" rel="noreferrer">
            💬 Rejoins la communauté sur WhatsApp
          </a>
        )}

        <section className="card">
          <h2>Proposer une idée</h2>
          <form onSubmit={submit}>
            <input placeholder="Titre de ton idée" value={title} maxLength={80} onChange={(e) => setTitle(e.target.value)} />
            <textarea placeholder="Explique-la en quelques mots (facultatif)" value={desc} maxLength={500} rows={3} onChange={(e) => setDesc(e.target.value)} />
            <button className="btn" disabled={busy || title.trim().length < 3}>
              {busy ? 'Envoi…' : user ? 'Publier mon idée' : 'Se connecter pour publier'}
            </button>
            {err && <p className="error">{err}</p>}
          </form>
        </section>

        <section>
          <h2>Les idées les plus votées</h2>
          {loading && <p className="muted">Chargement…</p>}
          <div className="grid">
            {ideas.map((idea, index) => (
              <article className="idea" key={idea.id}>
                <div className="rank">#{index + 1}</div>
                <h3>{idea.title}</h3>
                {idea.description && <p>{idea.description}</p>}
                <div className="foot">
                  <span className="muted">par {idea.author}</span>
                  <button className={`vote ${idea.voted ? 'on' : ''}`} onClick={() => vote(idea.id)}>
                    {idea.voted ? '✓ Voté' : '▲ Voter'} · {idea.votes}
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>
      </main>

      {showLogin && !user && (
        <div className="overlay" onClick={() => setShowLogin(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <button className="close" onClick={() => setShowLogin(false)} aria-label="Fermer">
              ✕
            </button>
            <PhoneLogin
              onLoggedIn={() => {
                setShowLogin(false);
                load();
              }}
            />
          </div>
        </div>
      )}
    </>
  );
}

/**
 * Envoi du code via l'API WhatsApp Business Cloud (Meta).
 * Il faut un modèle (template) de catégorie "Authentication" approuvé par Meta.
 *
 * ⚠️ WhatsApp ne permet PAS de savoir à l'avance si un numéro est "banni" ou "spamé".
 * On le déduit de la réponse à l'envoi : les codes d'erreur ci-dessous
 * sont traduits en messages clairs pour l'utilisateur.
 */
export type SendStatus =
  | { ok: true }
  | { ok: false; reason: 'no_whatsapp' | 'spam_limited' | 'rate_limited' | 'invalid_number' | 'server_error'; message: string };

const ERRORS: Record<number, { reason: any; message: string }> = {
  131026: { reason: 'no_whatsapp', message: "Ce numéro n'a pas WhatsApp ou ne peut pas recevoir de message." },
  131049: { reason: 'spam_limited', message: 'WhatsApp a limité les messages vers ce numéro (protection anti-spam). Réessaie plus tard.' },
  130429: { reason: 'rate_limited', message: "Trop d'envois pour le moment, réessaie dans quelques minutes." },
  131056: { reason: 'rate_limited', message: 'Trop de messages envoyés vers ce numéro, réessaie plus tard.' },
  131030: { reason: 'invalid_number', message: "Ce numéro n'est pas autorisé (mode test Meta : ajoute-le à la liste des destinataires)." },
  131021: { reason: 'invalid_number', message: "Numéro destinataire invalide." },
  133010: { reason: 'server_error', message: "Le numéro d'envoi du site n'est pas enregistré chez Meta." },
};

export async function sendWhatsAppCode(phoneE164: string, code: string): Promise<SendStatus> {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  const template = process.env.WHATSAPP_TEMPLATE_NAME || 'otp_code';
  const lang = process.env.WHATSAPP_TEMPLATE_LANG || 'fr';

  // Mode développement : pas de clés → le code s'affiche dans la console du serveur
  if (!token || !phoneId) {
    console.log(`[DEV] Code WhatsApp pour ${phoneE164} : ${code}`);
    return { ok: true };
  }

  try {
    const res = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: phoneE164.replace('+', ''),
        type: 'template',
        template: {
          name: template,
          language: { code: lang },
          components: [
            { type: 'body', parameters: [{ type: 'text', text: code }] },
            { type: 'button', sub_type: 'url', index: '0', parameters: [{ type: 'text', text: code }] },
          ],
        },
      }),
    });
    const data: any = await res.json().catch(() => ({}));
    if (res.ok) return { ok: true };
    const known = ERRORS[data?.error?.code];
    if (known) return { ok: false, ...known };
    console.error('WhatsApp error', data);
    return { ok: false, reason: 'server_error', message: "Impossible d'envoyer le code pour le moment." };
  } catch (e) {
    console.error(e);
    return { ok: false, reason: 'server_error', message: 'Erreur réseau, réessaie.' };
  }
}

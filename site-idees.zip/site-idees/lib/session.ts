import { cookies } from 'next/headers';
import { readSession } from './otp';
import { isBlocked } from './users';

/** Utilisateur connecté (ou null). À utiliser dans toutes les routes protégées. */
export async function getUser(): Promise<{ phone: string } | null> {
  const s = readSession((await cookies()).get('session')?.value);
  if (!s || (await isBlocked(s.phone))) return null;
  return s;
}

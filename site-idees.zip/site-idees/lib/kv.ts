/**
 * Mini base de données clé/valeur.
 * - Si UPSTASH_REDIS_REST_URL et UPSTASH_REDIS_REST_TOKEN sont définis : données conservées (Upstash, gratuit).
 * - Sinon : stockage en mémoire (parfait pour tester, perdu à chaque redémarrage).
 */
const URL = process.env.UPSTASH_REDIS_REST_URL;
const TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN;
const remote = !!(URL && TOKEN);

const g = globalThis as any;
g.__mem ??= new Map<string, { v: string; exp: number | null }>();
const mem: Map<string, { v: string; exp: number | null }> = g.__mem;

async function cmd(args: (string | number)[]): Promise<any> {
  const r = await fetch(URL!, {
    method: 'POST',
    headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(args),
    cache: 'no-store',
  });
  const d = await r.json();
  if (d.error) throw new Error(d.error);
  return d.result;
}

function memGet(key: string): string | null {
  const e = mem.get(key);
  if (!e) return null;
  if (e.exp && Date.now() > e.exp) {
    mem.delete(key);
    return null;
  }
  return e.v;
}

export async function kvGet<T = any>(key: string): Promise<T | null> {
  const raw = remote ? await cmd(['GET', key]) : memGet(key);
  if (raw == null) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export async function kvSet(key: string, value: unknown, ttlSec?: number): Promise<void> {
  const raw = JSON.stringify(value);
  if (remote) {
    await cmd(ttlSec ? ['SET', key, raw, 'EX', ttlSec] : ['SET', key, raw]);
  } else {
    mem.set(key, { v: raw, exp: ttlSec ? Date.now() + ttlSec * 1000 : null });
  }
}

export async function kvDel(key: string): Promise<void> {
  if (remote) await cmd(['DEL', key]);
  else mem.delete(key);
}

/** Compteur avec expiration (pour limiter les abus). Retourne la valeur après +1. */
export async function kvIncr(key: string, ttlSec: number): Promise<number> {
  if (remote) {
    const n = Number(await cmd(['INCR', key]));
    if (n === 1) await cmd(['EXPIRE', key, ttlSec]);
    return n;
  }
  const cur = Number(memGet(key) || 0) + 1;
  const old = mem.get(key);
  mem.set(key, { v: String(cur), exp: old?.exp && cur > 1 ? old.exp : Date.now() + ttlSec * 1000 });
  return cur;
}

/** true = autorisé, false = trop d'actions dans la fenêtre. */
export async function rateLimit(key: string, limit: number, windowSec: number): Promise<boolean> {
  return (await kvIncr(`rl:${key}`, windowSec)) <= limit;
}

import { parsePhoneNumberFromString } from 'libphonenumber-js';

/** Retourne le numéro au format E.164 (+241...) ou null s'il est invalide. */
export function normalizePhone(input: string, defaultCountry: any = 'GA'): string | null {
  const parsed = parsePhoneNumberFromString(String(input || '').trim(), defaultCountry);
  if (!parsed || !parsed.isValid()) return null;
  return parsed.number; // E.164
}

import { kvGet, kvSet } from './kv';

export type Idea = {
  id: string;
  title: string;
  description: string;
  author: string;
  createdAt: number;
  voters: string[]; // numéros ayant voté (jamais renvoyés au navigateur)
};

const seedVoters = (p: string, n: number) => Array.from({ length: n }, (_, k) => `seed-${p}-${k}`);

const SEED: Idea[] = [
  { id: 'seed-1', title: 'Application de covoiturage locale', description: "Mettre en relation les habitants qui font les mêmes trajets chaque jour.", author: 'Communauté', createdAt: Date.now() - 3 * 86400_000, voters: seedVoters('a', 14) },
  { id: 'seed-2', title: 'Marché en ligne des artisans', description: 'Une vitrine simple pour que les artisans vendent par WhatsApp.', author: 'Communauté', createdAt: Date.now() - 2 * 86400_000, voters: seedVoters('b', 9) },
  { id: 'seed-3', title: 'Cours de code gratuits pour débutants', description: 'Des mini-formations en français, pensées pour le téléphone.', author: 'Communauté', createdAt: Date.now() - 86400_000, voters: seedVoters('c', 6) },
];

export async function loadIdeas(): Promise<Idea[]> {
  const v = await kvGet<Idea[]>('ideas');
  if (v) return v;
  await kvSet('ideas', SEED);
  return SEED;
}

export const saveIdeas = (list: Idea[]) => kvSet('ideas', list);

export const maskPhone = (phone: string) => `${phone.slice(0, 4)} •••• ${phone.slice(-2)}`;

export function publicIdea(i: Idea, phone?: string) {
  const { voters, ...rest } = i;
  return { ...rest, votes: voters.length, voted: !!phone && voters.includes(phone) };
}

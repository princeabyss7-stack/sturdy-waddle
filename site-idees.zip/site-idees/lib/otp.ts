import crypto from 'crypto';
import { kvGet, kvSet, kvDel } from './kv';

export const OTP_TTL_SEC = 5 * 60; // le code expire après 5 min
export const RESEND_COOLDOWN_SEC = 60; // 1 min entre deux envois
export const MAX_ATTEMPTS = 5;

type OtpRecord = { hash: string; expiresAt: number; attempts: number; sentAt: number };

const secret = () => process.env.AUTH_SECRET || 'change-me-in-env';
const hash = (phone: string, code: string) =>
  crypto.createHmac('sha256', secret()).update(`${phone}:${code}`).digest('hex');

export function generateCode(): string {
  return String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');
}

export async function saveCode(phone: string, code: string) {
  const rec: OtpRecord = { hash: hash(phone, code), expiresAt: Date.now() + OTP_TTL_SEC * 1000, attempts: 0, sentAt: Date.now() };
  await kvSet(`otp:${phone}`, rec, OTP_TTL_SEC);
}

export async function cooldownLeft(phone: string): Promise<number> {
  const r = await kvGet<OtpRecord>(`otp:${phone}`);
  if (!r) return 0;
  return Math.max(0, Math.ceil((r.sentAt + RESEND_COOLDOWN_SEC * 1000 - Date.now()) / 1000));
}

export type VerifyResult = 'ok' | 'expired' | 'invalid' | 'too_many_attempts' | 'none';

export async function checkCode(phone: string, code: string): Promise<VerifyResult> {
  const key = `otp:${phone}`;
  const r = await kvGet<OtpRecord>(key);
  if (!r) return 'none';
  if (Date.now() > r.expiresAt) {
    await kvDel(key);
    return 'expired';
  }
  if (r.attempts >= MAX_ATTEMPTS) return 'too_many_attempts';
  r.attempts++;
  const left = Math.max(1, Math.ceil((r.expiresAt - Date.now()) / 1000));
  const a = Buffer.from(r.hash);
  const b = Buffer.from(hash(phone, code));
  if (a.length === b.length && crypto.timingSafeEqual(a, b)) {
    await kvDel(key); // code à usage unique
    return 'ok';
  }
  await kvSet(key, r, left);
  return 'invalid';
}

/* ---- Session : jeton signé dans un cookie httpOnly ---- */
const b64 = (s: string) => Buffer.from(s).toString('base64url');

export function signSession(phone: string, days = 30): string {
  const body = b64(JSON.stringify({ phone, exp: Date.now() + days * 86400_000 }));
  const sig = crypto.createHmac('sha256', secret()).update(body).digest('base64url');
  return `${body}.${sig}`;
}

export function readSession(token?: string | null): { phone: string } | null {
  if (!token) return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const expected = crypto.createHmac('sha256', secret()).update(body).digest('base64url');
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try {
    const data = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (Date.now() > data.exp) return null;
    return { phone: data.phone };
  } catch {
    return null;
  }
}

import { kvGet, kvSet } from './kv';

/** Numéros bloqués : variable BLOCKED_PHONES="+24101234567,+..." ou clé blocked:<numéro> dans la base. */
export async function isBlocked(phone: string): Promise<boolean> {
  const list = (process.env.BLOCKED_PHONES || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (list.includes(phone)) return true;
  return (await kvGet(`blocked:${phone}`)) === true;
}

/** Un seul compte par numéro : créé à la première connexion. */
export async function ensureUser(phone: string) {
  const existing = await kvGet(`user:${phone}`);
  if (existing) return existing;
  const user = { phone, createdAt: Date.now() };
  await kvSet(`user:${phone}`, user);
  return user;
}

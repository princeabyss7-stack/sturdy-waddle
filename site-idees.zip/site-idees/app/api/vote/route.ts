import { NextResponse } from 'next/server';
import { getUser } from '@/lib/session';
import { rateLimit } from '@/lib/kv';
import { loadIdeas, saveIdeas } from '@/lib/ideas';

/** Un vote par numéro et par idée. Re-cliquer retire le vote. */
export async function POST(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ ok: false, message: 'Connecte-toi pour voter.' }, { status: 401 });
  if (!(await rateLimit(`vote:${user.phone}`, 60, 3600))) {
    return NextResponse.json({ ok: false, message: 'Trop de votes, réessaie plus tard.' }, { status: 429 });
  }

  const { id } = await req.json().catch(() => ({}));
  const list = await loadIdeas();
  const idea = list.find((i) => i.id === id);
  if (!idea) return NextResponse.json({ ok: false, message: 'Idée introuvable.' }, { status: 404 });

  idea.voters = idea.voters.includes(user.phone) ? idea.voters.filter((p) => p !== user.phone) : [...idea.voters, user.phone];
  await saveIdeas(list);
  return NextResponse.json({ ok: true, votes: idea.voters.length });
}

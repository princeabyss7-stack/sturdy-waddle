import { NextResponse } from 'next/server';
import { getUser } from '@/lib/session';
import { rateLimit } from '@/lib/kv';
import { loadIdeas, saveIdeas, publicIdea, maskPhone, type Idea } from '@/lib/ideas';

export const dynamic = 'force-dynamic';

export async function GET() {
  const user = await getUser();
  const list = await loadIdeas();
  const ideas = list.map((i) => publicIdea(i, user?.phone)).sort((a, b) => b.votes - a.votes || b.createdAt - a.createdAt);
  return NextResponse.json({ ideas });
}

export async function POST(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ ok: false, message: 'Connecte-toi pour proposer une idée.' }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const title = String(body.title || '').trim();
  const description = String(body.description || '').trim();
  if (title.length < 3 || title.length > 80) {
    return NextResponse.json({ ok: false, message: 'Le titre doit faire entre 3 et 80 caractères.' }, { status: 400 });
  }
  if (description.length > 500) {
    return NextResponse.json({ ok: false, message: 'La description est trop longue (500 caractères max).' }, { status: 400 });
  }
  if (!(await rateLimit(`idea:${user.phone}`, 5, 86400))) {
    return NextResponse.json({ ok: false, message: "Tu as atteint la limite de 5 idées par jour." }, { status: 429 });
  }

  const list = await loadIdeas();
  const idea: Idea = {
    id: crypto.randomUUID(),
    title,
    description,
    author: maskPhone(user.phone),
    createdAt: Date.now(),
    voters: [user.phone], // l'auteur vote pour son idée
  };
  await saveIdeas([idea, ...list]);
  return NextResponse.json({ ok: true });
}

import { NextResponse } from 'next/server';
import { getUser } from '@/lib/session';

export const dynamic = 'force-dynamic';

export async function GET() {
  const user = await getUser();
  return NextResponse.json({ user });
}

export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  res.cookies.delete('session');
  return res;
}

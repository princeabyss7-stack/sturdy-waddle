import { NextResponse } from 'next/server';
import { normalizePhone } from '@/lib/phone';
import { checkCode, signSession } from '@/lib/otp';
import { rateLimit } from '@/lib/kv';
import { ensureUser, isBlocked } from '@/lib/users';

const MESSAGES: Record<string, string> = {
  expired: 'Code expiré. Demande un nouveau code.',
  invalid: 'Code incorrect.',
  too_many_attempts: "Trop d'essais. Demande un nouveau code.",
  none: 'Aucun code demandé pour ce numéro.',
};

export async function POST(req: Request) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
  const { phone: raw, code } = await req.json().catch(() => ({}));
  const phone = normalizePhone(raw);
  if (!phone || !/^\d{6}$/.test(String(code || ''))) {
    return NextResponse.json({ ok: false, error: 'invalid', message: 'Numéro ou code invalide.' }, { status: 400 });
  }
  if (!(await rateLimit(`verify:${ip}`, 30, 600))) {
    return NextResponse.json({ ok: false, error: 'rate_limited', message: 'Trop de tentatives.' }, { status: 429 });
  }
  if (await isBlocked(phone)) {
    return NextResponse.json({ ok: false, error: 'blocked', message: 'Compte bloqué.' }, { status: 403 });
  }

  const result = await checkCode(phone, String(code));
  if (result !== 'ok') {
    return NextResponse.json({ ok: false, error: result, message: MESSAGES[result] }, { status: 401 });
  }

  await ensureUser(phone);
  const res = NextResponse.json({ ok: true, phone });
  res.cookies.set('session', signSession(phone), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 30 * 86400,
  });
  return res;
}

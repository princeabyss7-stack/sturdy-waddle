import { NextResponse } from 'next/server';
import { normalizePhone } from '@/lib/phone';
import { generateCode, saveCode, cooldownLeft } from '@/lib/otp';
import { rateLimit } from '@/lib/kv';
import { isBlocked } from '@/lib/users';
import { sendWhatsAppCode } from '@/lib/whatsapp';

const err = (error: string, message: string, status = 400, extra: object = {}) =>
  NextResponse.json({ ok: false, error, message, ...extra }, { status });

export async function POST(req: Request) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
  const { phone: raw, country } = await req.json().catch(() => ({}));

  // 1. Format du numéro
  const phone = normalizePhone(raw, country || 'GA');
  if (!phone) return err('invalid_number', 'Numéro invalide. Vérifie le format (ex : +241 07 12 34 56).');

  // 2. Numéro bloqué
  if (await isBlocked(phone)) return err('blocked', "Ce numéro n'est pas autorisé à se connecter.", 403);

  // 3. Anti-spam : par IP et par numéro
  if (!(await rateLimit(`ip:${ip}`, 10, 600))) return err('rate_limited', 'Trop de tentatives, réessaie plus tard.', 429);
  if (!(await rateLimit(`phone:${phone}`, 3, 600))) return err('rate_limited', 'Trop de codes demandés pour ce numéro. Réessaie dans 10 minutes.', 429);

  // 4. Délai entre deux envois
  const wait = await cooldownLeft(phone);
  if (wait > 0) return err('cooldown', `Attends ${wait}s avant de redemander un code.`, 429, { retryAfter: wait });

  // 5. Envoi WhatsApp (détecte numéro sans WhatsApp / limité anti-spam)
  const code = generateCode();
  const result = await sendWhatsAppCode(phone, code);
  if (!result.ok) return err(result.reason, result.message, result.reason === 'server_error' ? 502 : 422);

  await saveCode(phone, code);

  // MODE TEST : tant que les clés WhatsApp ne sont pas configurées, on affiche le code à l'écran.
  const demo = !process.env.WHATSAPP_TOKEN || !process.env.WHATSAPP_PHONE_NUMBER_ID;
  return NextResponse.json({
    ok: true,
    phone,
    message: demo ? 'Mode test : WhatsApp non configuré.' : 'Code envoyé sur WhatsApp.',
    ...(demo ? { devCode: code } : {}),
  });
}

import './globals.css';
import type { ReactNode } from 'react';

export const metadata = {
  title: 'NextIdea – Les idées de la communauté',
  description: 'Propose tes idées, vote pour celles que tu aimes et vois naître les projets de la communauté.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body>{children}</body>
    </html>
  );
}
